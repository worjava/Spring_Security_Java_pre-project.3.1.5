package com.UsersMVC.users.controllers;


import com.UsersMVC.users.models.User;

import com.UsersMVC.users.services.RoleService;
import com.UsersMVC.users.services.UserServiceImpl;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@RestController
@RequestMapping("api/admin")
public class AdminController {

    private final UserServiceImpl userServiceImp;
    public final RoleService roleService;

    public AdminController(UserServiceImpl userService, RoleService roleService) {
        this.userServiceImp = userService;
        this.roleService = roleService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<User>> index() {
        List<User> users = userServiceImp.index();

        return users != null && !users.isEmpty()
                ? new ResponseEntity<>(users, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


    @PostMapping()
    public ResponseEntity<User> creat(@RequestBody @Valid User user) {
        userServiceImp.save(user);
        return new ResponseEntity<>(user, HttpStatus.OK);
    }

//    @PatchMapping("/{id}/edit")
//    public ResponseEntity<User> edit(@RequestBody @Valid User user) {
//        User userUpdate =userServiceImp.show(user.getId());
//    userServiceImp.save(userUpdate);
//    return  new ResponseEntity

    @DeleteMapping("{id}")
    public String delete(@PathVariable("id") int id) {
        userServiceImp.delete(id);
        return "redirect:/admin";
    }


}

